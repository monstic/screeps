/**
 * Allows to harvest a mineral deposit.
 *
 * @class
 * @extends {OwnedStructure}
 *
 * @see {@link http://support.screeps.com/hc/en-us/articles/207715739-StructureExtractor}
 */
StructureExtractor = function() { };

StructureExtractor.prototype =
{

};
